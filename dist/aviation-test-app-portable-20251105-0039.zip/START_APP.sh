#!/bin/bash
echo "================================================"
echo "  Aviation Test Center - Portable Launcher"
echo "================================================"
echo ""
echo "Starting local web server..."
echo ""
echo "Once started, open your browser to:"
echo "http://localhost:8000"
echo ""
echo "Press Ctrl+C to stop the server"
echo ""
echo "================================================"
echo ""

# Try Python 3 first, then Python 2
if command -v python3 &> /dev/null; then
    python3 -m http.server 8000
elif command -v python &> /dev/null; then
    python -m SimpleHTTPServer 8000
else
    echo "ERROR: Python is not installed!"
    echo ""
    echo "Please install Python or simply double-click index.html"
    echo ""
    read -p "Press Enter to exit..."
fi
