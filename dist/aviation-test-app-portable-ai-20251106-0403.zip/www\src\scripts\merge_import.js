// Merge window.agkWordImport into window.testData at runtime with de-duplication
(function(){
  if (!window || !window.testData || !window.agkWordImport) return;
  const data = window.testData;
  const imp = window.agkWordImport;
  const catKey = imp.category || 'aircraft-general';
  if (!data[catKey]) {
    data[catKey] = { name: 'Aircraft General Knowledge', icon: 'fas fa-plane', tests: [] };
  }
  const cat = data[catKey];

  function norm(s){ return String(s || '').toLowerCase().replace(/\s+/g,' ').trim(); }

  // Build a set of existing question stems across the category to de-duplicate broadly
  const existing = new Set();
  (cat.tests || []).forEach(t => (t.questions||[]).forEach(q => existing.add(norm(q.question))));

  // Merge tests
  for (const t of imp.tests || []) {
    const targetName = t.name && t.name.trim() ? t.name.trim() : 'AGK Import';
    let tgt = (cat.tests || []).find(x => x.name === targetName);
    if (!tgt) {
      tgt = { name: targetName, timeLimit: t.timeLimit || 60, questions: [] };
      cat.tests.push(tgt);
    }
    const before = tgt.questions.length;
    for (const q of t.questions || []) {
      if (!q || !q.question || !Array.isArray(q.options) || q.options.length < 2) continue;
      const key = norm(q.question);
      if (existing.has(key)) continue; // skip duplicates
      // Normalize correct index; default to 0 if missing
      let correct = typeof q.correct === 'number' ? q.correct : 0;
      if (correct < 0 || correct >= q.options.length) correct = 0;
      tgt.questions.push({ question: q.question.trim(), options: q.options.map(String), correct, explanation: null });
      existing.add(key);
    }
    if (tgt.questions.length !== before) {
      // Keep list tidy: optional sort by question text
      // tgt.questions.sort((a,b)=>a.question.localeCompare(b.question));
    }
  }

  // Expose back
  window.testData = data;
})();
