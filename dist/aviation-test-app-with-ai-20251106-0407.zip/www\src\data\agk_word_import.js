// Generated from Word HTML on 2025-11-06T00:56:47.764Z
window.agkWordImport = {
  "category": "aircraft-general",
  "tests": [
    {
      "name": "Aircraft General Knowledge Test 1",
      "timeLimit": 60,
      "questions": [
        {
          "question": "If an artificial feel unit were fitted it would be connected:",
          "options": [
            "in parallel with the primary controls",
            "in series with the primary controls",
            "in series with the secondary controls",
            "in parallel with the secondary controls"
          ],
          "correct": 1
        }
      ]
    },
    {
      "name": "Aircraft General Knowledge Test 2",
      "timeLimit": 60,
      "questions": [
        {
          "question": "The purpose of a ditching control valve is:",
          "options": [
            "to close the outflow valves",
            "to open outflow valves",
            "to allow rapid depressurisation",
            "to dump the toilet water after landing"
          ],
          "correct": 0
        }
      ]
    },
    {
      "name": "Aircraft General Knowledge Test 3",
      "timeLimit": 60,
      "questions": [
        {
          "question": "How do you control power in a jet engine?",
          "options": [
            "By controlling the mixture ratio",
            "By controlling the fuel flow",
            "By controlling the airflow",
            "By controlling the bleed valves"
          ],
          "correct": 1
        }
      ]
    },
    {
      "name": "Aircraft General Knowledge Test 4",
      "timeLimit": 60,
      "questions": [
        {
          "question": "An artificial feel system is needed in the pitch channel if the:",
          "options": [
            "airplane has a variable incidence tailplane",
            "elevators are controlled through a reversible servo system",
            "elevator is controlled through a servo tab",
            "elevators are controlled through an irreversible servo system"
          ],
          "correct": 3
        }
      ]
    },
    {
      "name": "Aircraft General Knowledge Test 5",
      "timeLimit": 60,
      "questions": [
        {
          "question": "On what principle does the fuel contents gauging system work on a modern large aircraft?",
          "options": [
            "Capacity affected by dielectric therefore changing EMF of system 154",
            "Capacity affected by dielectric therefore changing resistivity of system",
            "Changes in dielectric causes changes in capacitance 155D. Change in dielectric causes change in distance between plates and therefore changes capacitance 156"
          ],
          "correct": 2
        }
      ]
    }
  ]
};
